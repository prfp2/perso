# Module: default
# Author: Rayflix, noway
# Created on: 19.01.2022
import xbmcplugin
from urllib.parse import quote_plus, unquote_plus, parse_qsl
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
from io import BytesIO
from urllib.request import urlopen
from zipfile import ZipFile
import os
import shutil
import requests
import random
import re

artworkPath = xbmcvfs.translatePath('special://home/addons/plugin.program.skinrayflix/resources/media/')
fanart = artworkPath + "fanart.jpg"

def notice(content):
    log(content, xbmc.LOGINFO)

def log(msg, level=xbmc.LOGINFO):
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    xbmc.log('%s: %s' % (addonID, msg), level)

def showErrorNotification(message):
    xbmcgui.Dialog().notification("UptoRay", message,
                                  xbmcgui.NOTIFICATION_ERROR, 5000)
def showInfoNotification(message):
    xbmcgui.Dialog().notification("UptoRay", message, xbmcgui.NOTIFICATION_INFO, 15000)

def add_dir(name, mode, thumb):
    u = sys.argv[0] + "?" + "action=" + str(mode)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': thumb})
    liz.setProperty("fanart_image", fanart)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def main_menu():
    xbmcplugin.setPluginCategory(__handle__, "Choix UptoRay")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("[COLOR red]METTRE A JOUR L'ADDON[/COLOR]", 'ad_maj2', artworkPath + 'icone.png')
    add_dir("Mettre a jour les icones", 'au_maj', artworkPath + 'icone.png')    
    add_dir("[COLOR deepskyblue]COMPTES PREMIUM ALEATOIRE CLIC ICI[/COLOR]", 'menuKey', artworkPath + 'icone.png')
    add_dir("Choix SKins [COLOR red]U2Pplay HK[/COLOR] Clic ici", 'hk', artworkPath + 'icone.png')
    add_dir("Choix SKins [COLOR green]vStream[/COLOR] Clic ici", 'vstream', artworkPath + 'icone.png')
    add_dir("Sauvegarde et restauration", 'save_restor', artworkPath + 'icone.png')
    add_dir("[COLOR red]NETTOYER KODI[/COLOR]", 'nettoye', artworkPath + 'icone.png')
    add_dir("Test", 'test_test', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)

def test_test():
    xbmcplugin.setPluginCategory(__handle__, "Test")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("test install", '', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)

def hk():
    xbmcplugin.setPluginCategory(__handle__, "Choix skin HK")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("Activer Mise a Jour Database Automatique [COLOR red]Clic ici[/COLOR]", 'db_auto', artworkPath + 'icone.png')
    add_dir("[COLOR red]u2Play[/COLOR] SKIN LIGHT [COLOR deepskyblue](le + leger)[/COLOR]", 'choixskinlite', artworkPath + 'icone.png')
    add_dir("[COLOR red]u2Play[/COLOR] SKIN FULL [COLOR deepskyblue](le + gourmand)[/COLOR]", 'choixskinfull', artworkPath + 'icone.png')
    add_dir("[COLOR red]u2Play[/COLOR] SKIN KIDS [COLOR deepskyblue](special enfants)[/COLOR]", 'choixskinkids', artworkPath + 'icone.png')
    add_dir("Desactiver Mise a Jour Database Automatique [COLOR red]Clic ici[/COLOR]", 'db_auto_no', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)

def db_auto():
    #active autoexec
    xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "service.autoexec", "enabled": true }}')
    xbmc.sleep(2000)
    #notification
    xbmc.executebuiltin("Notification(AUTOEXEC, activé...)")

def db_auto_no():
    #desactive autoexec
    xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "service.autoexec", "enabled": false }}')
    xbmc.sleep(2000)
    #notification
    xbmc.executebuiltin("Notification(AUTOEXEC, désactivé...)")

def vstream():
    xbmcplugin.setPluginCategory(__handle__, "Choix skin vStream")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("Ajouter les Codes Past pour [COLOR green]vStream[/COLOR] Clic ici", 'choixpastall', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]COMPTES PREMIUM ALEATOIRE CLIC ICI[/COLOR]", 'menuKey', artworkPath + 'icone.png')
    add_dir("[COLOR green]vStream[/COLOR] SKIN LIGHT [COLOR deepskyblue](le + leger)[/COLOR]", 'choixskinlitev', artworkPath + 'icone.png')
    add_dir("[COLOR green]vStream[/COLOR] SKIN FULL [COLOR deepskyblue](le + gourmand)[/COLOR]", 'choixskinfullv', artworkPath + 'icone.png')
    add_dir("[COLOR green]vStream[/COLOR] SKIN KIDS [COLOR deepskyblue](special enfants)[/COLOR]", 'choixskinkidsv', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)

def nettoye():
    xbmcplugin.setPluginCategory(__handle__, "NETTOYER KODI")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("[COLOR red]NETTOYER TOUT D'UN COUP : [/COLOR]clic ici", 'vider_cache', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]Vider Cache uniquement[/COLOR]", 'cache_seul', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]Vider Tmp uniquement[/COLOR]", 'tmp_seul', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]Vider Packages uniquement[/COLOR]", 'package_seul', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]Vider Thumbnails uniquement[/COLOR]", 'thumb_seul', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)       
       
def save_restor():
    xbmcplugin.setPluginCategory(__handle__, "Sauvegarde et restauration")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("[COLOR deepskyblue]1 CREER UNE SAUVEGARDE : [/COLOR]", 'skin_save1', artworkPath + 'icone.png')
    add_dir("Emplacement 1", 'skin_save1', artworkPath + 'icone.png')
    add_dir("Emplacement 2", 'skin_save2', artworkPath + 'icone.png')
    add_dir("Emplacement 3", 'skin_save3', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]2 RESTAURER UNE SAUVEGARDE : [/COLOR]", 'skin_restor1', artworkPath + 'icone.png')
    add_dir("Emplacement 1", 'skin_restor1', artworkPath + 'icone.png')
    add_dir("Emplacement 2", 'skin_restor2', artworkPath + 'icone.png')
    add_dir("Emplacement 3", 'skin_restor3', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)   

def skin_restor1():
    # copie des fichiers sauvegarde
    source_dir = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/1/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/1/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(COPIE OK,Mise à jour effectuée !)")
    xbmc.sleep(5000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(ACTUALISATION DU SKIN, Skin Save 1...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')
    sys.exit()

def skin_restor2():
    # copie des fichiers sauvegarde
    source_dir = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/2/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/2/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(COPIE OK,Mise à jour effectuée !)")
    xbmc.sleep(5000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(ACTUALISATION DU SKIN, Skin Save 2...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')
    sys.exit()

def skin_restor3():
    # copie des fichiers sauvegarde
    source_dir = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/3/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/3/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(COPIE OK,Mise à jour effectuée !)")
    xbmc.sleep(5000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(ACTUALISATION DU SKIN, Skin Save 3...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')
    sys.exit()

def skin_save1():
    xbmc.executebuiltin("Notification(PREPARATION DES FICHIERS,Copie en cours...)")
    # COPIE DES DOSSIERS ET FICHIERS DU SKIN
    source_dir = xbmc.translatePath('special://home/userdata/addon_data/skin.project.aura')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/1/addon_data/skin.project.aura')
    source_dir1 = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts')
    destination_dir1 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/1/addon_data/script.skinshortcuts')
    source_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura/1080i/script-skinshortcuts-includes.xml')
    destination_dir2 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/1/addons/skin.project.aura/1080i/script-skinshortcuts-includes.xml')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir1, destination_dir1, dirs_exist_ok=True)
    shutil.copy(source_dir2, destination_dir2)
    # CREATION ARCHIVE ZIP
    shutil.make_archive((xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/Skin_save1')),'zip',(xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/1')))
    xbmc.executebuiltin("Notification(SKIN SAUVEGARDE, Archive ZIP créée !)")
    sys.exit()

def skin_save2():
    xbmc.executebuiltin("Notification(PREPARATION DES FICHIERS,Copie en cours...)")
    # COPIE DES DOSSIERS ET FICHIERS DU SKIN
    source_dir = xbmc.translatePath('special://home/userdata/addon_data/skin.project.aura')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/2/addon_data/skin.project.aura')
    source_dir1 = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts')
    destination_dir1 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/2/addon_data/script.skinshortcuts')
    source_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura/1080i/script-skinshortcuts-includes.xml')
    destination_dir2 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/2/addons/skin.project.aura/1080i/script-skinshortcuts-includes.xml')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir1, destination_dir1, dirs_exist_ok=True)
    shutil.copy(source_dir2, destination_dir2)
    # CREATION ARCHIVE ZIP
    shutil.make_archive((xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/Skin_save1')),'zip',(xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/2')))
    xbmc.executebuiltin("Notification(SKIN SAUVEGARDE, Archive ZIP créée !)")
    sys.exit()

def skin_save3():
    xbmc.executebuiltin("Notification(PREPARATION DES FICHIERS,Copie en cours...)")
    # COPIE DES DOSSIERS ET FICHIERS DU SKIN
    source_dir = xbmc.translatePath('special://home/userdata/addon_data/skin.project.aura')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/3/addon_data/skin.project.aura')
    source_dir1 = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts')
    destination_dir1 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/3/addon_data/script.skinshortcuts')
    source_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura/1080i/script-skinshortcuts-includes.xml')
    destination_dir2 = xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/3/addons/skin.project.aura/1080i/script-skinshortcuts-includes.xml')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir1, destination_dir1, dirs_exist_ok=True)
    shutil.copy(source_dir2, destination_dir2)
    # CREATION ARCHIVE ZIP
    shutil.make_archive((xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/Skin_save1')),'zip',(xbmc.translatePath('special://home/userdata/addon_data/Scripts/Skin_save/3')))
    xbmc.executebuiltin("Notification(SKIN SAUVEGARDE, Archive ZIP créée !)")
    sys.exit()

def menuKey():
    tabkey = extractAnotpad()
    nb = 0
    ok = False
    while tabkey:
        keyUpto = random.choice(tabkey)
        status, validite = testUptobox(keyUpto)
        if status == "Success":
            showInfoNotification("Notification(Key Upto ok! expire: %s)" %validite)
            ok = True
            break
        else:
            tabkey.remove(keyUpto)
            showErrorNotification("Prevenir Ray key: %s HS" %keyUpto)
            nb += 1
        if nb > 50:
            break
            return
    if ok:
        # config u2play
        try:
            addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
            addon.setSetting(id="keyupto", value=keyUpto)
            nb_items = "50"
            addon.setSetting(id="nb_items", value=nb_items)
            thumbnails = "5000"
            addon.setSetting(id="thumbnails", value=thumbnails)
        except Exception as e:
            notice("Erreur HK: " + str(e))
        
        # config vstream
        try:
            addon = xbmcaddon.Addon("plugin.video.vstream")
            cache_v = "8"
            addon.setSetting(id="pastebin_cacheDuration", value=cache_v)
            addon.setSetting(id="hoster_uptobox_token", value=keyUpto)
        except Exception as e:
            notice("Erreur Vstream: " + str(e))
        
        #config catchup
        try:
            addon = xbmcaddon.Addon("plugin.video.catchuptvandmore")
            mail = "rayflix@laposte.net"
            mot2passe = "Mot2passe"
            addon.setSetting(id="nrj.login", value=mail)
            addon.setSetting(id="6play.login", value=mail)
            addon.setSetting(id="rmcbfmplay.login", value=mail)
            addon.setSetting(id="nrj.password", value=mot2passe)
            addon.setSetting(id="6play.password", value=mot2passe)
            addon.setSetting(id="rmcbfmplay.password", value=mot2passe)
        except Exception as e:
            notice("Erreur CatchUp: " + str(e))

        showInfoNotification("Config Comptes ok")

def importSkin(zipurl):
    # telechargement et extraction du zip
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))
    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(COPIE SKIN OK,Faites retour et profitez !)")
    xbmc.sleep(2000)

     
def importpastall():
    addon = xbmcaddon.Addon("plugin.video.vstream")
    hoster_uptobox_premium = "true"
    addon.setSetting(id="hoster_uptobox_premium", value=hoster_uptobox_premium)
    hoster_uptobox_mode_default = "2"
    addon.setSetting(id="hoster_uptobox_mode_default", value=hoster_uptobox_mode_default)
    meta_view = "true"
    addon.setSetting(id="meta-view", value=meta_view)
    upnext = "true"
    addon.setSetting(id="upnext", value=upnext)
    cache_v = "8"
    addon.setSetting(id="pastebin_cacheDuration", value=cache_v)
    pastebin_id_1 = "EO8B4UZW7"
    addon.setSetting(id="pastebin_id_1", value=pastebin_id_1)
    pastebin_id_10 = "bpoH873I9"
    addon.setSetting(id="pastebin_id_10", value=pastebin_id_10)
    pastebin_id_10_1 = "ivwIfh7qb"
    addon.setSetting(id="pastebin_id_10_1", value=pastebin_id_10_1)
    pastebin_id_11 = "cahgbQSA8"
    addon.setSetting(id="pastebin_id_11", value=pastebin_id_11)
    pastebin_id_11_1 = "gRbZHH5Oc"
    addon.setSetting(id="pastebin_id_11_1", value=pastebin_id_11_1)
    pastebin_id_12 = "ZToZ91oO4"
    addon.setSetting(id="pastebin_id_12", value=pastebin_id_12)
    pastebin_id_13 = "1lkVORzJ5"
    addon.setSetting(id="pastebin_id_13", value=pastebin_id_13)
    pastebin_id_13_1 = "8DGNwgF1f"
    addon.setSetting(id="pastebin_id_13_1", value=pastebin_id_13_1)
    pastebin_id_14 = "ivwIfh7qb"
    addon.setSetting(id="pastebin_id_14", value=pastebin_id_14)
    pastebin_id_14_1 = "NR23nBfya"
    addon.setSetting(id="pastebin_id_14_1", value=pastebin_id_14_1)
    pastebin_id_14_2 = "8alNscZhb"
    addon.setSetting(id="pastebin_id_14_2", value=pastebin_id_14_2)
    pastebin_id_14_3 = "gRbZHH5Oc"
    addon.setSetting(id="pastebin_id_14_3", value=pastebin_id_14_3)
    pastebin_id_14_4 = "McEEgDVj1"
    addon.setSetting(id="pastebin_id_14_4", value=pastebin_id_14_4)
    pastebin_id_14_5 = "w8hid9uH"
    addon.setSetting(id="pastebin_id_14_5", value=pastebin_id_14_5)
    pastebin_id_14_6 = "L939ssub"
    addon.setSetting(id="pastebin_id_14_6", value=pastebin_id_14_6)
    pastebin_id_16 = "NR23nBfya"
    addon.setSetting(id="pastebin_id_16", value=pastebin_id_16)
    pastebin_id_17 = "8alNscZhb"
    addon.setSetting(id="pastebin_id_17", value=pastebin_id_17)
    pastebin_id_19 = "XK7j5qF96"
    addon.setSetting(id="pastebin_id_19", value=pastebin_id_19)
    pastebin_id_1_1 = "DQd9XEEm6"
    addon.setSetting(id="pastebin_id_1_1", value=pastebin_id_1_1)
    pastebin_id_1_2 = "wkMH4RQm5"
    addon.setSetting(id="pastebin_id_1_2", value=pastebin_id_1_2)
    pastebin_id_1_3 = "As9WHeYcd"
    addon.setSetting(id="pastebin_id_1_3", value=pastebin_id_1_3)
    pastebin_id_1_4 = "aNFsyvg0d"
    addon.setSetting(id="pastebin_id_1_4", value=pastebin_id_1_4)
    pastebin_id_1_5 = "gv90T7ND"
    addon.setSetting(id="pastebin_id_1_5", value=pastebin_id_1_5)
    pastebin_id_1_6 = "TqJ5TG82"
    addon.setSetting(id="pastebin_id_1_6", value=pastebin_id_1_6)
    pastebin_id_2 = "5lzzQ3Nf8"
    addon.setSetting(id="pastebin_id_2", value=pastebin_id_2)
    pastebin_id_20 = "FGp4wyWNe"
    addon.setSetting(id="pastebin_id_20", value=pastebin_id_20)
    pastebin_id_20_1 = "eVQYTD9Ee"
    addon.setSetting(id="pastebin_id_20_1", value=pastebin_id_20_1)
    pastebin_id_20_2 = "n6Ktq4be"
    addon.setSetting(id="pastebin_id_20_2", value=pastebin_id_20_2)
    pastebin_id_20_3 = "8HtzXrRg"
    addon.setSetting(id="pastebin_id_20_3", value=pastebin_id_20_3)
    pastebin_id_21 = "lXYORyXO3"
    addon.setSetting(id="pastebin_id_21", value=pastebin_id_21)
    pastebin_id_21_1 = "QQznKBon5"
    addon.setSetting(id="pastebin_id_21_1", value=pastebin_id_21_1)
    pastebin_id_21_2 = "mSVoqQs14"
    addon.setSetting(id="pastebin_id_21_2", value=pastebin_id_21_2)
    pastebin_id_21_3 = "gCRp5jAJ"
    addon.setSetting(id="pastebin_id_21_3", value=pastebin_id_21_3)
    pastebin_id_22 = "bdtseyFo4"
    addon.setSetting(id="pastebin_id_22", value=pastebin_id_22)
    pastebin_id_22_1 = "Cj6CFsWF6"
    addon.setSetting(id="pastebin_id_22_1", value=pastebin_id_22_1)
    pastebin_id_22_2 = "hYUEwk4x9"
    addon.setSetting(id="pastebin_id_22_2", value=pastebin_id_22_2)
    pastebin_id_22_3 = "pT8rVZWJ"
    addon.setSetting(id="pastebin_id_22_3", value=pastebin_id_22_3)
    pastebin_id_23 = "MGLq4580f"
    addon.setSetting(id="pastebin_id_23", value=pastebin_id_23)
    pastebin_id_24 = "iXADPTLZa"
    addon.setSetting(id="pastebin_id_24", value=pastebin_id_24)
    pastebin_id_24_1 = "3XhU0eJk"
    addon.setSetting(id="pastebin_id_24_1", value=pastebin_id_24_1)
    pastebin_id_24_2 = "V355mvgB"
    addon.setSetting(id="pastebin_id_24_2", value=pastebin_id_24_2)
    pastebin_id_25 = "Ji83AZwJ1"
    addon.setSetting(id="pastebin_id_25", value=pastebin_id_25)
    pastebin_id_25_1 = "OMJTcEtZ7"
    addon.setSetting(id="pastebin_id_25_1", value=pastebin_id_25_1)
    pastebin_id_26 = "R2wGRfIMb"
    addon.setSetting(id="pastebin_id_26", value=pastebin_id_26)
    pastebin_id_26_1 = "2BF30f4e4"
    addon.setSetting(id="pastebin_id_26_1", value=pastebin_id_26_1)
    pastebin_id_26_2 = "4gpjJrO83"
    addon.setSetting(id="pastebin_id_26_2", value=pastebin_id_26_2)
    pastebin_id_26_3 = "4pqkAIgkc"
    addon.setSetting(id="pastebin_id_26_3", value=pastebin_id_26_3)
    pastebin_id_26_4 = "mKmgkcV5"
    addon.setSetting(id="pastebin_id_26_4", value=pastebin_id_26_4)
    pastebin_id_27 = "9Y8NCn5d7"
    addon.setSetting(id="pastebin_id_27", value=pastebin_id_27)
    pastebin_id_28 = "EO8B4UZW7"
    addon.setSetting(id="pastebin_id_28", value=pastebin_id_28)
    pastebin_id_28_1 = "kiodqgoE8"
    addon.setSetting(id="pastebin_id_28_1", value=pastebin_id_28_1)
    pastebin_id_29 = "QLVajut4c"
    addon.setSetting(id="pastebin_id_29", value=pastebin_id_29)
    pastebin_id_2_1 = "pdMvZoA99"
    addon.setSetting(id="pastebin_id_2_1", value=pastebin_id_2_1)
    pastebin_id_3 = "aGu9J5VY2"
    addon.setSetting(id="pastebin_id_3", value=pastebin_id_3)
    pastebin_id_30 = "lXYORyXO3"
    addon.setSetting(id="pastebin_id_30", value=pastebin_id_30)
    pastebin_id_30_1 = "eVQYTD9Ee"
    addon.setSetting(id="pastebin_id_30_1", value=pastebin_id_30_1)
    pastebin_id_4 = "WfJ963s7f"
    addon.setSetting(id="pastebin_id_4", value=pastebin_id_4)
    pastebin_id_5 = "ScHQtWTO3"
    addon.setSetting(id="pastebin_id_5", value=pastebin_id_5)
    pastebin_id_5_1 = "jGDuxPue6"
    addon.setSetting(id="pastebin_id_5_1", value=pastebin_id_5_1)
    pastebin_id_5_2 = "c4OkvO4Ad"
    addon.setSetting(id="pastebin_id_5_2", value=pastebin_id_5_2)
    pastebin_id_5_3 = "cHGYFxWPe"
    addon.setSetting(id="pastebin_id_5_3", value=pastebin_id_5_3)
    pastebin_id_5_4 = "MIeBPnB34"
    addon.setSetting(id="pastebin_id_5_4", value=pastebin_id_5_4)
    pastebin_id_5_5 = "9Y8NCn5d7"
    addon.setSetting(id="pastebin_id_5_5", value=pastebin_id_5_5)
    pastebin_id_5_6 = "gyA3W3W4"
    addon.setSetting(id="pastebin_id_5_6", value=pastebin_id_5_6)
    pastebin_id_5_7 = "yTq332KL"
    addon.setSetting(id="pastebin_id_5_7", value=pastebin_id_5_7)
    pastebin_id_6 = "2GhLj0fwf"
    addon.setSetting(id="pastebin_id_6", value=pastebin_id_6)
    pastebin_id_7 = "cvcsVyFH0"
    addon.setSetting(id="pastebin_id_7", value=pastebin_id_7)
    pastebin_id_8 = "As9WHeYcd"
    addon.setSetting(id="pastebin_id_8", value=pastebin_id_8)
    pastebin_id_9 = "QLVajut4c"
    addon.setSetting(id="pastebin_id_9", value=pastebin_id_9)
    pastebin_id_9_1 = "bpoH873I9"
    addon.setSetting(id="pastebin_id_9_1", value=pastebin_id_9_1)
    pastebin_id_9_2 = "ZToZ91oO4"
    addon.setSetting(id="pastebin_id_9_2", value=pastebin_id_9_2)
    pastebin_id_9_3 = "cahgbQSA8"
    addon.setSetting(id="pastebin_id_9_3", value=pastebin_id_9_3)
    pastebin_id_9_4 = "QLwYtqtU8"
    addon.setSetting(id="pastebin_id_9_4", value=pastebin_id_9_4)
    pastebin_id_9_5 = "m3gQSW5q"
    addon.setSetting(id="pastebin_id_9_5", value=pastebin_id_9_5)
    pastebin_id_9_6 = "QrA8uVNU"
    addon.setSetting(id="pastebin_id_9_6", value=pastebin_id_9_6)
    pastebin_label_1 = "1 Films Apres 2000 (tous)"
    addon.setSetting(id="pastebin_label_1", value=pastebin_label_1)
    pastebin_label_10 = "5 Disney Anime"
    addon.setSetting(id="pastebin_label_10", value=pastebin_label_10)
    pastebin_label_11 = "5 SuperHeros Anime"
    addon.setSetting(id="pastebin_label_11", value=pastebin_label_11)
    pastebin_label_12 = "5 DAnime Films Autres"
    addon.setSetting(id="pastebin_label_12", value=pastebin_label_12)
    pastebin_label_13 = "5 Films Series Enfants"
    addon.setSetting(id="pastebin_label_13", value=pastebin_label_13)
    pastebin_label_14 = "6 DAnime Series (tous)"
    addon.setSetting(id="pastebin_label_14", value=pastebin_label_14)
    pastebin_label_16 = "6 DAnime Series petits"
    addon.setSetting(id="pastebin_label_16", value=pastebin_label_16)
    pastebin_label_17 = "6 DAnime Series grands"
    addon.setSetting(id="pastebin_label_17", value=pastebin_label_17)
    pastebin_label_19 = "6 Dessin Anime 80"
    addon.setSetting(id="pastebin_label_19", value=pastebin_label_19)
    pastebin_label_2 = "1 Films Avant 2000"
    addon.setSetting(id="pastebin_label_2", value=pastebin_label_2)
    pastebin_label_20 = "7 Docs Films (tous)"
    addon.setSetting(id="pastebin_label_20", value=pastebin_label_20)
    pastebin_label_21 = "7 Docs Series (tous)"
    addon.setSetting(id="pastebin_label_21", value=pastebin_label_21)
    pastebin_label_22 = "8 Concert"
    addon.setSetting(id="pastebin_label_22", value=pastebin_label_22)
    pastebin_label_23 = "8 Humoriste"
    addon.setSetting(id="pastebin_label_23", value=pastebin_label_23)
    pastebin_label_24 = "8 Spectacle"
    addon.setSetting(id="pastebin_label_24", value=pastebin_label_24)
    pastebin_label_25 = "8 Sports"
    addon.setSetting(id="pastebin_label_25", value=pastebin_label_25)
    pastebin_label_26 = "9 Mangas (tous)"
    addon.setSetting(id="pastebin_label_26", value=pastebin_label_26)
    pastebin_label_27 = "Series Selection"
    addon.setSetting(id="pastebin_label_27", value=pastebin_label_27)
    pastebin_label_28 = "widget Films et Series"
    addon.setSetting(id="pastebin_label_28", value=pastebin_label_28)
    pastebin_label_29 = "widget dessin animé"
    addon.setSetting(id="pastebin_label_29", value=pastebin_label_29)
    pastebin_label_3 = "1 Films SuperHeros"
    addon.setSetting(id="pastebin_label_3", value=pastebin_label_3)
    pastebin_label_30 = "widget doc"
    addon.setSetting(id="pastebin_label_30", value=pastebin_label_30)
    pastebin_label_4 = "4 Films 3D"
    addon.setSetting(id="pastebin_label_4", value=pastebin_label_4)
    pastebin_label_5 = "2 Series Apres 2000 (tous)"
    addon.setSetting(id="pastebin_label_5", value=pastebin_label_5)
    pastebin_label_6 = "2 Series Avant 2000"
    addon.setSetting(id="pastebin_label_6", value=pastebin_label_6)
    pastebin_label_7 = "3 Series Anime Adulte"
    addon.setSetting(id="pastebin_label_7", value=pastebin_label_7)
    pastebin_label_8 = "Films 2020 et plus"
    addon.setSetting(id="pastebin_label_8", value=pastebin_label_8)
    pastebin_label_9 = "5 DAnime Films (tous)"
    addon.setSetting(id="pastebin_label_9", value=pastebin_label_9)
    showInfoNotification("Ajout Past All ok")
    '''
    # telechargement et extraction du zip
    zipurl = 'https://github.com/prf2/pack/raw/kodi/p_all.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))
    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(ALL PAST OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)
    '''

def ad_maj2():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/prf2/pack/raw/kodi/ad_maj2.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))
    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/')
    destination_dir2 = xbmc.translatePath('special://home/addons/')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(EXTRACTION OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def au_maj():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/prf2/pack/raw/kodi/au_maj.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))
    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons')
    destination_dir2 = xbmc.translatePath('special://home/addons')
    source_dir3 = xbmc.translatePath('special://home/temp/temp/keymaps')
    destination_dir3 = xbmc.translatePath('special://home/userdata/keymaps')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    shutil.copytree(source_dir3, destination_dir3, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(EXTRACTION OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def vider_cache():
    xbmc.executebuiltin("Notification(FICHIER TEMP,Effacement en cours...)")
    # suppression dossier temporaire
    dirPath = xbmc.translatePath('special://home/temp/temp/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    xbmc.executebuiltin("Notification(DOSSIER PACKAGES,Effacement en cours...)")
    # suppression dossier packages
    dirPath = xbmc.translatePath('special://home/addons/packages/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    xbmc.executebuiltin("Notification(DOSSIER THUMBNAILS,Effacement en cours...)")
    # suppression dossier thumbnails
    dirPath = xbmc.translatePath('special://home/userdata/Thumbnails/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    xbmc.executebuiltin("Notification(CACHE TEMP,Effacement en cours...)")
    # suppression dossier cache
    dirPath = xbmc.translatePath('special://home/cache/temp/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(ATTENTION KODI VA SE FERMER , Relancez le...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')
    xbmc.sleep(2000)
    xbmc.executebuiltin('Quit')

def tmp_seul():
    xbmc.executebuiltin("Notification(FICHIER TEMP,Effacement en cours...)")
    # suppression dossier temporaire
    dirPath = xbmc.translatePath('special://home/temp/temp/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    xbmc.executebuiltin("Notification(TERMINE , ...)")
    # actualisation du skin
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')
    
def package_seul():
    xbmc.executebuiltin("Notification(DOSSIER PACKAGES,Effacement en cours...)")
    # suppression dossier packages
    dirPath = xbmc.translatePath('special://home/addons/packages/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(TERMINE , ...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')

def thumb_seul():
    xbmc.executebuiltin("Notification(DOSSIER THUMBNAILS,Effacement en cours...)")
    # suppression dossier thumbnails
    dirPath = xbmc.translatePath('special://home/userdata/Thumbnails/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(ATTENTION KODI VA SE FERMER , Relancez le...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')
    xbmc.sleep(2000)
    xbmc.executebuiltin('Quit')

def cache_seul():
    xbmc.executebuiltin("Notification(CACHE TEMP,Effacement en cours...)")
    # suppression dossier cache
    dirPath = xbmc.translatePath('special://home/cache/temp/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(TERMINE , ...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')

def extractAnotpad():
    numAnotepad = __addon__.getSetting("numAnotepad")
    motifAnotepad = r'.*<\s*div\s*class\s*=\s*"\s*plaintext\s*"\s*>(?P<txAnote>.+?)</div>.*'
    url = "https://anotepad.com/note/read/" + numAnotepad.strip()
    rec = requests.get(url)
    r = re.match(motifAnotepad, rec.text, re.MULTILINE|re.DOTALL)
    tabKey = [x.strip() for x in r.group("txAnote").splitlines() if x]
    return tabKey 

def testUptobox(key):
    url = 'https://uptobox.com/api/user/me?token=' + key
    headers = {'Accept': 'application/json'}
    try:
        data = requests.get(url, headers=headers).json()
        status = data["message"]
        validite = data["data"]["premium_expire"]
    except:
        status = "out"
        validite = ""
    return status, validite 

def router(paramstring):
    params = dict(parse_qsl(paramstring))    
    dictActions = {
        #key uptobox
        'menuKey':(menuKey, ""),
        #skin
        'choixpastall': (importpastall, ""),
        'choixskinlite': (importSkin, 'https://github.com/prf2/pack/raw/kodi/u_light.zip'),
        'choixskinfull': (importSkin, 'https://github.com/prf2/pack/raw/kodi/u_full.zip'),
        'choixskinkids': (importSkin, 'https://github.com/prf2/pack/raw/kodi/u_kids.zip'),
        'choixskinlitev': (importSkin, 'https://github.com/prf2/pack/raw/kodi/v_light.zip'),
        'choixskinfullv': (importSkin, 'https://github.com/prf2/pack/raw/kodi/v_full.zip'),
        'choixskinkidsv': (importSkin, 'https://github.com/prf2/pack/raw/kodi/v_kids.zip'),
        #skin hk
        'hk': (hk, ""),
        'db_auto': (db_auto, ""),
        'db_auto_no': (db_auto_no, ""),
        #skin vstream
        "vstream": (vstream, ""),
        #nettoyage
        'vider_cache': (vider_cache, ""),
        'cache_seul': (cache_seul, ""),
        'tmp_seul': (tmp_seul, ""),
        'package_seul': (package_seul, ""),
        'thumb_seul': (thumb_seul, ""),
        'nettoye': (nettoye, ""),
        #sauvegarde restauration
        'save_restor': (save_restor, ""),
        'skin_save1': (skin_save1, ""), 
        'skin_save2': (skin_save2, ""), 
        'skin_save3': (skin_save3, ""), 
        'skin_restor1': (skin_restor1, ""), 
        'skin_restor2': (skin_restor2, ""), 
        'skin_restor3': (skin_restor3, ""), 
        #autres
        'ad_maj2': (ad_maj2, ""),
        'au_maj': (au_maj, ""),
        #test
        'test_test': (test_test, ""),
        }
        

    if params:
        fn = params['action']
        if fn in dictActions.keys():
            argv = dictActions[fn][1]
            if argv:
                dictActions[fn][0](argv)
            else:
                dictActions[fn][0]()
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
         main_menu()

if __name__ == '__main__':
    __addon__ = xbmcaddon.Addon("plugin.program.skinrayflix")
    __handle__ = int(sys.argv[1])
    router(sys.argv[2][1:])